mundial_clubes2015 = ["Barcelona", "River Plate", "Sanfrecce", "Guangzhou"]
print("Os 3 primeiros colocados são: ", mundial_clubes2015[0:3])
print("Os 2 últimos colocados são: ", mundial_clubes2015[-2:])
print("Os times em ordem alfabética: ", sorted(mundial_clubes2015))
print("O time do Barcelona está na posição: ", mundial_clubes2015.index("Barcelona") + 1)
